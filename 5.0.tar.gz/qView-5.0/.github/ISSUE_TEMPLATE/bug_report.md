---
name: Bug report
about: Report a fault in the program's functionality
title: ''
labels: bug
assignees: ''

---

**Environment:**
- OS: [e.g. macOS 10.15 Catalina, Windows 10, Ubuntu 20.04, Arch Linux]
- qView version: [e.g. 3.0, nightly 2020-05-02.1]

**Information:**
This is the place where you write a description of your problem and how to reproduce it.
