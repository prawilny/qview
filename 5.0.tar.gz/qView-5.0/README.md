<h1 align=center>qView</h1>

<p align=center>qView is an image viewer designed with minimalism and usability in mind.</p>

<h3 align=center>
    <a href="https://interversehq.com/qview/">Visit the website</a>
</h3>

<h4 align=center>
    <a href="https://interversehq.com/qview/download">Downloads</a> |
    <a href="https://interversehq.com/qview/changelog">Changelog</a> | <a href="https://interversehq.com/discord">Discord</a>
</h4>

<p align=center>
    <a href="https://interversehq.com/qview/download">
        <img alt="Downloads shield" src="https://img.shields.io/github/downloads/jurplel/qview/total?color=blue&style=flat-square">
    </a>
    <a href="https://aur.archlinux.org/packages/qview/">
        <img alt="AUR shield" src="https://img.shields.io/aur/version/qview?style=flat-square">
    </a>
    <a href="https://formulae.brew.sh/cask/qview">
        <img alt="Homebrew cask shield" src="https://img.shields.io/homebrew/cask/v/qview?style=flat-square">
    </a>
</p>

<p align=center>
    <img alt="Screenshot" src="https://interversehq.com/qview/assets/img/screenshot3.png">
</p>
